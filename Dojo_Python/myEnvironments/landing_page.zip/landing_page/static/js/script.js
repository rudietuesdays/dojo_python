$(document).ready(function(){
    console.log('it works');

    $('.submit').on('click', function(){
        return false;
    })

})
