from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse
from .forms import RegisterForm
from .models import Note

def index(request):

    context = {
        "regForm": form,
        }
    return render(request, "awesomeApp_templates/index.html", context)

def register(request):
    # Confirm that the HTTP verb was a POST
    if request.method == "POST":
        # Bind the POST data to an instance of our RegisterForm
        bound_form = RegisterForm(request.POST)
        # Now test that bound_form using built-in methods!
        # *************************
        print bound_form.is_valid() # True or False, based on the validations that were set!
        print bound_form.errors # Any errors in this form as a dictionary
        # *************************

def dashboard(request):
    notes = Note.objects.all()
    form = RegisterForm()

    print notes

    context = {
        'notes': notes,
    }

    return render(request, "awesomeApp_templates/notes.html", context)

def write_note(request):
    Note.objects.create(note=request.POST['note'])
    return redirect(reverse('awesomeApp:dashboard'))
