### AWESOME APP URLS ###
from django.conf.urls import url
from . import views

app_name = 'awesomeApp'
urlpatterns = [
# Your app's urls is lined to the project
    url(r'^$', views.index, name='index'),
    url(r'^notes$', views.dashboard, name='dashboard'),
    url(r'^write$', views.write_note, name='write'),
]
