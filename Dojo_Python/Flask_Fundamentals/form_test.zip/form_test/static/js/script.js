$(document).ready(function(){
    console.log('time for some forms!');

    $('button').click(function(){
        location.href = '/'
    })
})
