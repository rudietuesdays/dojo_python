from __future__ import unicode_literals

from django.apps import AppConfig


class AjaxNoteConfig(AppConfig):
    name = 'ajax_note'
